import { NextRequest, NextResponse } from "next/server";
import { Prisma, OrderStatus } from "@prisma/client";
import { prisma } from "@/lib/prisma.server";
import { getSession, getUserRestaurant, requireRestaurantOwner } from "@/lib/auth";
import { processOrderCommission } from "@/lib/commission.server";
import { createBillFromOrder } from "@/lib/billing.server";
import { isTestMode, logTestMode } from "@/lib/test-mode";

export const dynamic = "force-dynamic";

export async function PATCH(
  request: NextRequest,
  context: { params: Promise<{ id: string }> }
) {
  try {
    // Await params (Next.js 16 requirement)
    const params = await context.params;
    const { id } = params;

    // Test mode short-circuit for fast E2E tests
    if (isTestMode) {
      logTestMode(`/api/kitchen/orders/${id} PATCH`);
      const body = await request.json().catch(() => ({}));
      const { status } = body as { status?: string };
      return NextResponse.json(
        {
          message: "Order status updated successfully",
          order: {
            id,
            status: status || "ACCEPTED",
            type: "DINE_IN",
            total: 500,
            tableName: "Table 1",
            items: [{ id: "item-1", name: "Test Item", quantity: 1, price: 500 }],
            updatedAt: new Date().toISOString(),
          },
          success: true,
        },
        { status: 200 }
      );
    }

    // Validate ID
    if (!id || typeof id !== "string" || id.trim().length === 0) {
      return NextResponse.json(
        { error: "Invalid order ID", success: false },
        { status: 400 }
      );
    }

    // Require restaurant owner authentication
    const user = await requireRestaurantOwner();

    // Get user's restaurant
    const restaurant = await getUserRestaurant(user.id);
    if (!restaurant) {
      return NextResponse.json(
        { error: "Restaurant not found", success: false },
        { status: 404 }
      );
    }

    // Parse request body
    let body: unknown;
    try {
      body = await request.json();
    } catch (parseError) {
      console.error("Invalid JSON body:", parseError);
      return NextResponse.json(
        { error: "Invalid JSON body", success: false },
        { status: 400 }
      );
    }

    const { status } = (body ?? {}) as { status?: unknown };

    // Validate status
    if (!status || typeof status !== "string") {
      return NextResponse.json(
        { error: "Status is required", success: false },
        { status: 400 }
      );
    }

    const validStatuses = ["PENDING", "ACCEPTED", "PREPARING", "SERVED", "CANCELLED"];
    if (!validStatuses.includes(status)) {
      return NextResponse.json(
        { error: `Invalid status. Must be one of: ${validStatuses.join(", ")}`, success: false },
        { status: 400 }
      );
    }

    // Verify order exists and belongs to restaurant
    const existingOrder = await prisma.order.findFirst({
      where: {
        id: id.trim(),
        restaurantId: restaurant.id,
      },
    });

    if (!existingOrder) {
      return NextResponse.json(
        { error: "Order not found or access denied", success: false },
        { status: 404 }
      );
    }

    // Update order status
    try {
      const updatedOrder = await prisma.order.update({
        where: { id: id.trim() },
        data: { status: status as OrderStatus },
        include: {
          table: {
            select: {
              id: true,
              name: true,
            },
          },
          items: {
            include: {
              menuItem: {
                select: {
                  id: true,
                  name: true,
                },
              },
            },
          },
        },
      });

      // If order is SERVED, calculate commission and create bill automatically
      if (status === "SERVED") {
        // Process commission (non-blocking)
        try {
          const commissionResult = await processOrderCommission(updatedOrder.id);
          if (commissionResult.success && commissionResult.commissionId) {
            console.log(`Commission calculated for order ${updatedOrder.id}: ${commissionResult.commissionId}`);
          } else if (commissionResult.error) {
            console.warn(`Commission calculation failed for order ${updatedOrder.id}: ${commissionResult.error}`);
          }
          // Don't fail the order update if commission calculation fails
        } catch (commissionError) {
          console.error("Error processing commission:", commissionError);
          // Continue with order update even if commission fails
        }

        // Create bill from order (non-blocking)
        try {
          const billResult = await createBillFromOrder(updatedOrder.id);
          if (billResult.success && billResult.billId) {
            console.log(`Bill created for order ${updatedOrder.id}: ${billResult.billId}`);
          } else if (billResult.error) {
            console.warn(`Bill creation failed for order ${updatedOrder.id}: ${billResult.error}`);
          }
          // Don't fail the order update if bill creation fails
        } catch (billError) {
          console.error("Error creating bill from order:", billError);
          // Continue with order update even if bill creation fails
        }
      }

      return NextResponse.json(
        {
          message: "Order status updated successfully",
          order: {
            id: updatedOrder.id,
            status: updatedOrder.status,
            type: updatedOrder.type,
            total: updatedOrder.total,
            tableName: updatedOrder.table?.name || `Table ${updatedOrder.tableId?.slice(-4) || "N/A"}`,
            items: updatedOrder.items.map((item) => ({
              id: item.id,
              name: item.menuItem.name,
              quantity: item.quantity,
              price: item.price,
            })),
            updatedAt: updatedOrder.updatedAt.toISOString(),
          },
          success: true,
        },
        { status: 200 }
      );
    } catch (prismaError) {
      console.error("Prisma update error:", prismaError);

      if (prismaError instanceof Prisma.PrismaClientKnownRequestError) {
        if (prismaError.code === "P2025") {
          return NextResponse.json(
            { error: "Order not found", success: false },
            { status: 404 }
          );
        }
      }

      throw prismaError;
    }
  } catch (error) {
    console.error("Kitchen order PATCH error:", error);

    if (error instanceof Error && error.message.includes("Authentication")) {
      return NextResponse.json(
        { error: "Authentication required", success: false },
        { status: 401 }
      );
    }

    if (error instanceof Error && error.message.includes("Restaurant owner")) {
      return NextResponse.json(
        { error: "Restaurant owner access required", success: false },
        { status: 403 }
      );
    }

    if (error instanceof Error) {
      return NextResponse.json(
        { error: `Internal server error: ${error.message}`, success: false },
        { status: 500 }
      );
    }

    return NextResponse.json(
      { error: "Internal server error", success: false },
      { status: 500 }
    );
  }
}
