# Dashboard Screenshots

Add real dashboard screenshots here for the homepage:

- `dashboard.png` - Main dashboard view
- `orders.png` - Orders management screen
- `billing.png` - Billing page

Recommended size: 1200×720 or similar 16:9 aspect ratio.

If files are missing, the homepage shows a placeholder with a QR icon.
