-- AlterEnum
ALTER TYPE "OrderStatus" ADD VALUE 'PAID';
